import UIKit

var testClosure: (String) -> () = { name in
    print(name)
}

testClosure("Juan")
